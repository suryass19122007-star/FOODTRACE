import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowLeft, ArrowRight, Check, ChevronDown, CircleAlert, MapPin,
  QrCode, ShieldCheck, X, CalendarDays, Building2, PackageCheck,
  Leaf, Truck, Store, Factory, ShoppingBasket
} from "lucide-react";
import "./styles.css";

type Lang = "en" | "ta";
type Stage = {
  key: string; icon: React.ElementType; title: string; ta: string;
  date?: string; location?: string; party: string; id?: string;
  description: string; evidence: string; status: "verified" | "incomplete" | "traceable";
  human: string; x: number; y: number;
};

const stages: Stage[] = [
  {key:"farm",icon:Leaf,title:"Farm",ta:"பண்ணை",date:"05 SEPTEMBER 2026",location:"Thanjavur, Tamil Nadu",party:"Farmer cooperative",id:"FARM-TNJ-050926",description:"Rice harvested and entered into the traceability chain.",evidence:"Harvest record • Field entry • Origin record",status:"verified",human:"Respect for farmers and transparent origin.",x:24,y:73},
  {key:"collection",icon:PackageCheck,title:"Collection",ta:"சேகரிப்பு",date:"06 SEPTEMBER 2026",location:"Thanjavur, Tamil Nadu",party:"Collection centre",id:"COL-TNJ-060926",description:"Produce received, weighed and grouped for processing.",evidence:"Weighing record • Collection receipt",status:"verified",human:"Fairness through accountable handling.",x:32,y:65},
  {key:"processing",icon:Factory,title:"Processing",ta:"செயலாக்கம்",date:"07 SEPTEMBER 2026",location:"Thanjavur, Tamil Nadu",party:"Processing facility",id:"PROC-TNJ-070926",description:"The harvested produce was cleaned, processed and prepared for packing.",evidence:"Processing log • Quality check",status:"verified",human:"Quality and responsibility at every step.",x:43,y:57},
  {key:"manufactured",icon:Factory,title:"Manufactured",ta:"உற்பத்தி",date:"10 SEPTEMBER 2026",location:"Thanjavur, Tamil Nadu",party:"Food manufacturer",id:"BATCH-100926-TNJ",description:"Final product manufactured and assigned to a traceable batch.",evidence:"Production record • Batch record • Facility record",status:"verified",human:"Safety, accountability and traceability.",x:55,y:48},
  {key:"stored",icon:Building2,title:"Stored",ta:"சேமிப்பு",date:"11 SEPTEMBER 2026",location:"Chennai, Tamil Nadu",party:"Cold / dry storage",id:"STO-CHN-110926",description:"Product entered storage before distribution. Some supporting evidence is incomplete.",evidence:"Storage entry • Temperature record pending",status:"incomplete",human:"Honesty about what is known and what is missing.",x:66,y:39},
  {key:"distributed",icon:Truck,title:"Distributed",ta:"விநியோகம்",date:"12 SEPTEMBER 2026",location:"Chennai → Tambaram",party:"Distribution partner",description:"Product moved from the storage point towards retail.",evidence:"Dispatch event • Route event",status:"verified",human:"Responsible movement and visibility.",x:76,y:31},
  {key:"consumer",icon:ShoppingBasket,title:"Consumer",ta:"நுகர்வோர்",party:"Consumer scan",description:"A consumer scanned the QR code to view the product journey and available evidence.",evidence:"QR scan event",status:"traceable",human:"Informed choice through accessible information.",x:86,y:22}
];

const copy = {
  en: {
    scanTitle:"Scan to Trace", scanText:"Scan the QR code on your food package to see its journey from farm to you.",
    scan:"SCAN QR CODE", choose:"Choose your language", english:"English", tamil:"தமிழ்",
    dashboard:"FoodTrace Dashboard", journey:"Product Journey", verified:"Verified", incomplete:"Incomplete",
    traceable:"Traceable", records:"verified records", viewGaps:"View Information Gaps",
    human:"Human Values", gapsTitle:"Information Gaps", close:"Close", back:"Back",
    map:"Traceability Map", select:"Select a stage to explore its evidence.",
    noLocation:"No location recorded for this stage."
  },
  ta: {
    scanTitle:"தடமறிய ஸ்கேன் செய்யவும்", scanText:"உங்கள் உணவுப் பொதியில் உள்ள QR குறியீட்டை ஸ்கேன் செய்து, பண்ணையிலிருந்து உங்களிடம் வந்த பயணத்தைப் பார்க்கவும்.",
    scan:"QR குறியீட்டை ஸ்கேன் செய்க", choose:"உங்கள் மொழியைத் தேர்வு செய்யவும்", english:"English", tamil:"தமிழ்",
    dashboard:"FoodTrace டாஷ்போர்டு", journey:"தயாரிப்பு பயணம்", verified:"சரிபார்க்கப்பட்டது", incomplete:"முழுமையற்றது",
    traceable:"தடமறியக்கூடியது", records:"சரிபார்க்கப்பட்ட பதிவுகள்", viewGaps:"தகவல் குறைபாடுகளைக் காண்க",
    human:"மனித மதிப்புகள்", gapsTitle:"தகவல் குறைபாடுகள்", close:"மூடு", back:"பின்செல்",
    map:"தடமறிதல் வரைபடம்", select:"ஆதாரங்களைப் பார்க்க ஒரு கட்டத்தைத் தேர்வு செய்யவும்.",
    noLocation:"இந்த கட்டத்திற்கு இடம் பதிவு செய்யப்படவில்லை."
  }
};

function App(){
  const [screen,setScreen] = useState<"scan"|"language"|"dashboard">("scan");
  const [lang,setLang] = useState<Lang>("en");
  const [selected,setSelected] = useState(0);
  const [gaps,setGaps] = useState(false);
  const t = copy[lang];

  if(screen==="scan") return <Scan onNext={()=>setScreen("language")} t={t}/>;
  if(screen==="language") return <Language lang={lang} setLang={setLang} onNext={()=>setScreen("dashboard")} onBack={()=>setScreen("scan")} t={t}/>;
  return <Dashboard lang={lang} setLang={setLang} selected={selected} setSelected={setSelected} gaps={gaps} setGaps={setGaps} onBack={()=>setScreen("language")} t={t}/>;
}

function Scan({onNext,t}:{onNext:()=>void,t:any}){
  return <main className="screen scan-screen">
    <div className="brand"><span className="brand-mark"><Leaf size={20}/></span> FoodTrace</div>
    <div className="scan-card">
      <div className="eyebrow">FOOD • TRUST • TRACEABILITY</div>
      <h1>{t.scanTitle}</h1>
      <p>{t.scanText}</p>
      <div className="qr-frame"><QrCode size={112}/><span className="scan-line"/></div>
      <button className="primary" onClick={onNext}>{t.scan}<ArrowRight size={18}/></button>
      <div className="secure"><ShieldCheck size={16}/> Evidence-led product history</div>
    </div>
  </main>
}

function Language({lang,setLang,onNext,onBack,t}:{lang:Lang,setLang:(x:Lang)=>void,onNext:()=>void,onBack:()=>void,t:any}){
  return <main className="screen centered">
    <button className="back" onClick={onBack}><ArrowLeft size={17}/>{t.back}</button>
    <div className="language-card">
      <div className="round-icon"><Leaf size={28}/></div>
      <div className="eyebrow">FOODTRACE</div>
      <h1>{t.choose}</h1>
      <div className="language-options">
        <button className={lang==="en"?"selected-lang":""} onClick={()=>setLang("en")}><span>EN</span>{t.english}<Check size={18}/></button>
        <button className={lang==="ta"?"selected-lang":""} onClick={()=>setLang("ta")}><span>தமிழ்</span>{t.tamil}<Check size={18}/></button>
      </div>
      <button className="primary wide" onClick={onNext}>{lang==="en"?"CONTINUE":"தொடரவும்"}<ArrowRight size={18}/></button>
    </div>
  </main>
}

function Dashboard({lang,setLang,selected,setSelected,gaps,setGaps,onBack,t}:{lang:Lang,setLang:(x:Lang)=>void,selected:number,setSelected:(x:number)=>void,gaps:boolean,setGaps:(x:boolean)=>void,onBack:()=>void,t:any}){
  const s=stages[selected];
  const verified=stages.filter(x=>x.status==="verified").length;
  return <div className="dashboard">
    <header><button className="brand-btn" onClick={onBack}><span className="brand-mark"><Leaf size={18}/></span> FoodTrace</button>
      <div className="header-right"><span className="live"><i/> LIVE TRACE</span><div className="toggle"><button className={lang==="en"?"on":""} onClick={()=>setLang("en")}>EN</button><button className={lang==="ta"?"on":""} onClick={()=>setLang("ta")}>தமிழ்</button></div></div>
    </header>
    <section className="hero">
      <div><div className="eyebrow">BATCH BATCH-100926-TNJ</div><h1>{t.dashboard}</h1><p>{t.select}</p></div>
      <div className="summary"><div><b>{verified+1}</b><span>{t.records}</span></div><div><b>1</b><span>{t.incomplete}</span></div><div><b>1</b><span>{t.traceable}</span></div></div>
    </section>
    <div className="content">
      <section className="timeline-panel"><div className="section-title"><h2>{t.journey}</h2><span>7 STAGES</span></div>
        <div className="timeline">{stages.map((stage,i)=>{
          const Icon=stage.icon; const active=i===selected;
          return <div className={"stage "+(active?"active":"")} key={stage.key}>
            <button className="stage-head" onClick={()=>setSelected(i)}>
              <div className="stage-marker"><Icon size={17}/></div><div className="stage-title"><strong>{lang==="ta"?stage.ta:stage.title}</strong><small>{stage.location || t.noLocation}</small></div>
              <span className={"status "+stage.status}>{stage.status==="verified"?t.verified:stage.status==="incomplete"?t.incomplete:t.traceable}</span><ChevronDown className={active?"rot":""} size={18}/>
            </button>
            {active && <div className="stage-detail">
              {stage.key==="manufactured" && <div className="manufactured-banner"><b>10 SEPTEMBER 2026</b><span>✓ Production record</span><span>✓ Batch record</span><span>✓ Facility record</span></div>}
              <div className="detail-grid">
                <div><label>DATE</label><strong>{stage.date||"—"}</strong></div><div><label>LOCATION</label><strong>{stage.location||t.noLocation}</strong></div>
                <div><label>RESPONSIBLE PARTY</label><strong>{stage.party}</strong></div><div><label>ID / BATCH</label><strong>{stage.id||"—"}</strong></div>
              </div>
              <p>{stage.description}</p><div className="evidence"><b>EVIDENCE</b><span>{stage.evidence}</span></div>
              <div className="human"><span>HUMAN VALUE</span>{stage.human}</div>
              {stage.status==="incomplete" && <button className="gap-link" onClick={()=>setGaps(true)}><CircleAlert size={16}/>{t.viewGaps}</button>}
            </div>}
          </div>
        })}</div>
      </section>
      <section className="map-panel"><div className="section-title"><h2>{t.map}</h2><span>NO API KEY</span></div>
        <div className="map">
          <div className="state-shape"><span> TAMIL NADU </span></div>
          <svg className="routes" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M24 73 Q42 55 55 48 T86 22" /><path className="secondary" d="M32 65 Q48 55 66 39 T76 31" />
          </svg>
          {stages.map((x,i)=><button key={x.key} className={"map-dot "+(i===selected?"selected":"")} style={{left:x.x+"%",top:x.y+"%"}} onClick={()=>setSelected(i)} title={x.title}><span>{i+1}</span></button>)}
          <div className="map-label chennai">Chennai</div><div className="map-label thanjavur">Thanjavur</div><div className="map-label tambaram">Tambaram</div>
          <div className="map-card"><b>{lang==="ta"?s.ta:s.title}</b><span>{s.location||t.noLocation}</span></div>
        </div>
      </section>
    </div>
    {gaps && <div className="modal-backdrop" onClick={()=>setGaps(false)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setGaps(false)}><X/></button><div className="round-icon amber"><CircleAlert/></div><h2>{t.gapsTitle}</h2><p>The Stored stage has a missing temperature record. Missing evidence does not automatically mean wrongdoing; it means the available record is incomplete and should be checked or completed.</p><div className="gap-item"><b>Pending evidence</b><span>Temperature record for storage</span></div><button className="primary wide" onClick={()=>setGaps(false)}>{t.close}</button></div></div>}
  </div>
}

createRoot(document.getElementById("root")!).render(<App />);
