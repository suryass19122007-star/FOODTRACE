# FoodTrace

A Vite + React + TypeScript demo for food traceability.

## Run

Open this folder in VS Code, then open **Terminal → New Terminal**.

```bash
npm install
npm run dev
```

Open the Local URL shown by Vite (usually http://localhost:5173/).

## Included
- QR scan screen
- English/Tamil language selection
- Traceability dashboard
- Seven-stage timeline
- Manufactured-stage evidence banner
- Interactive stylized Tamil Nadu map
- Information gaps modal
- Responsive desktop/mobile layout

The map is intentionally API-key-free for the demo.
